# Thriftie Trip – Toko Thrift Import (tampilan toko online)

Website statis (HTML + CSS + JS), siap dipasang di **GitHub Pages**.

## Cara pasang di GitHub
1. Buat repository baru, upload `index.html`, `style.css`, `app.js` (dan `products.json` jika ada).
2. Settings → Pages → pilih branch `main`, folder `/ (root)`, Save.
3. Website tayang di `https://USERNAME.github.io/NAMA-REPO/`.

## Fitur
- Tampilan toko online: pencarian, kategori negara, Flash Sale dengan hitung mundur, diskon, bar terjual, urutan produk
- Halaman detail produk, keranjang dengan jumlah, checkout tamu atau akun, gratis ongkir otomatis, konfirmasi lewat WhatsApp
- Daftar dan masuk akun

## Kelola toko (tanpa coding)
Scroll ke paling bawah, klik **Kelola toko**, masukkan PIN (bawaan `1234`, ganti di `app.js` pada `ADMIN_PIN`).
- Tab **Produk**: nama, harga jual, harga coret (diskon dihitung otomatis), stok, terjual, negara, ukuran, kondisi, deskripsi, tampil di Flash Sale, foto asli (link atau upload)
- Tab **Pengaturan toko**: nama toko, Instagram, nomor WhatsApp, batas gratis ongkir, warna utama, warna Flash Sale, waktu berakhir Flash Sale, teks banner
- Klik **Simpan perubahan**. Data tersimpan di browser yang dipakai.
- Supaya tampil untuk semua pengunjung: klik **Ekspor products.json**, lalu upload file itu ke repository (folder yang sama dengan `index.html`).

## Foto produk
Selama foto belum diisi, tampil ilustrasi baju netral sebagai pengganti. Begitu foto asli diisi, foto menggantikan ilustrasi.

## Catatan sebelum jualan sungguhan
Situs statis menyimpan akun, keranjang, dan pesanan di browser pengunjung. Cocok untuk demo. Untuk toko sungguhan, hubungkan ke backend (Firebase/Supabase) dan pembayaran (Midtrans/Xendit). PIN admin hanya pengaman ringan.
