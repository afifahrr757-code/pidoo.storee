// ====== PENGATURAN TOKO (bisa diubah lewat menu "Kelola toko" di bagian bawah website) ======
const DEFAULT_SETTINGS={name:"Thriftie Trip",brand:"#0B8A6B",flash:"#E63946",wa:"",freeShip:300000,flashEnd:"",
  bannerTitle:"Thrift import pilihan dari 4 negara",bannerSub:"Baju bekas berkualitas yang dicek satu per satu. Stok terbatas, siapa cepat dia dapat.",instagram:"@thriftietrip"};

// ====== DATA PRODUK (contoh). Ganti lewat "Kelola toko" atau edit di sini ======
// price = harga jual, orig = harga coret (0 = tanpa diskon), stock = sisa stok, sold = jumlah terjual, flash = tampil di Flash Sale
const DEFAULTS=[
  {id:1,name:"Cardigan Pastel Rajut",from:"Jepang",size:"M",cond:"9/10",price:89000,orig:129000,stock:3,sold:18,flash:true,desc:"Cardigan rajut lembut warna lavender dengan kancing depan. Bahan tebal dan hangat, cocok untuk kuliah atau santai.",shape:"cardigan",color:"#C9B8FF",accent:"#FFFFFF",pat:"knit",img:""},
  {id:2,name:"Rok Mini Pita Kotak-kotak",from:"Korea",size:"S",cond:"9/10",price:75000,orig:110000,stock:2,sold:24,flash:true,desc:"Rok mini motif kotak dengan pita di pinggang. Lipit rapi, karet di belakang jadi nyaman dipakai.",shape:"skirt",color:"#FFB3D1",accent:"#FF5A8F",pat:"plaid",img:""},
  {id:3,name:"Jaket Varsity Retro",from:"Amerika",size:"L",cond:"8/10",price:185000,orig:260000,stock:1,sold:9,flash:true,desc:"Jaket varsity lengan kontras dengan patch huruf. Ada sedikit tanda pemakaian di manset, tidak mengganggu.",shape:"jacket",color:"#FFF3D6",accent:"#FF7BA9",pat:"",img:""},
  {id:4,name:"Scarf Rajut Tebal",from:"Inggris",size:"All size",cond:"9/10",price:55000,orig:75000,stock:5,sold:31,flash:true,desc:"Scarf rajut tebal dengan rumbai dan aksen garis. Hangat untuk cuaca dingin atau ruangan ber-AC.",shape:"scarf",color:"#8FD9B6",accent:"#FFFFFF",pat:"knit",img:""},
  {id:5,name:"Kemeja Flanel Kotak Oversize",from:"Amerika",size:"XL",cond:"8/10",price:95000,orig:135000,stock:2,sold:12,flash:false,desc:"Kemeja flanel oversize dengan dua saku dada. Bisa dipakai sebagai outer.",shape:"shirt",color:"#FF8A80",accent:"#FFFFFF",pat:"plaid",img:""},
  {id:6,name:"Dress Floral Vintage",from:"Jepang",size:"M",cond:"9/10",price:135000,orig:190000,stock:1,sold:7,flash:false,desc:"Dress tali motif bunga dengan pita pinggang. Potongan A-line jatuh dan ringan.",shape:"dress",color:"#FFD1E3",accent:"#FF7BA9",pat:"floral",img:""},
  {id:7,name:"Celana Jeans Wide Leg",from:"Korea",size:"M",cond:"9/10",price:120000,orig:165000,stock:3,sold:21,flash:true,desc:"Jeans wide leg pinggang tinggi, warna biru medium. Bahan denim tebal dan tidak melar.",shape:"jeans",color:"#7C9BE0",accent:"#FFFFFF",pat:"denim",img:""},
  {id:8,name:"Hoodie Telinga Beruang",from:"Jepang",size:"L",cond:"9/10",price:110000,orig:150000,stock:2,sold:15,flash:false,desc:"Hoodie dengan tudung bertelinga beruang dan kantong kanguru. Bagian dalam lembut.",shape:"bear",color:"#FFB3D1",accent:"#FFFFFF",pat:"",img:""},
  {id:9,name:"Trench Coat Klasik",from:"Inggris",size:"M",cond:"8/10",price:210000,orig:320000,stock:1,sold:5,flash:false,desc:"Trench coat double breasted dengan ikat pinggang. Warna krem netral, mudah dipadukan.",shape:"coat",color:"#DDBE90",accent:"#F5E3C3",pat:"",img:""},
  {id:10,name:"Kaos Band Vintage",from:"Amerika",size:"L",cond:"8/10",price:85000,orig:0,stock:4,sold:27,flash:false,desc:"Kaos hitam keunguan dengan sablon bintang. Bahan katun, warna masih pekat.",shape:"tee",color:"#4A3A5C",accent:"#FFE58F",pat:"",img:""},
  {id:11,name:"Topi Bucket Stroberi",from:"Korea",size:"All size",cond:"10/10",price:45000,orig:60000,stock:6,sold:40,flash:true,desc:"Topi bucket motif stroberi dengan pita putih. Kondisi seperti baru.",shape:"hat",color:"#FFC2D4",accent:"#FFFFFF",pat:"berry",img:""},
  {id:12,name:"Sweater Argyle Preppy",from:"Inggris",size:"M",cond:"9/10",price:99000,orig:145000,stock:2,sold:11,flash:false,desc:"Sweater rajut motif argyle dengan kerah bulat. Gaya preppy yang rapi.",shape:"sweater",color:"#FFF1B8",accent:"#FF7BA9",pat:"argyle",img:""}
];
const FLAGS={Jepang:"🇯🇵",Korea:"🇰🇷",Amerika:"🇺🇸",Inggris:"🇬🇧",Prancis:"🇫🇷",Jerman:"🇩🇪",Italia:"🇮🇹",Australia:"🇦🇺",Thailand:"🇹🇭",China:"🇨🇳"};
const flagOf=c=>FLAGS[c]||"🌍";

// ====== HELPER ======
const $=s=>document.querySelector(s);
const rp=n=>"Rp"+Math.round(n||0).toLocaleString("id-ID");
const load=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}};
const save=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch{}};
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const imgTag=p=>/^(https?:|data:image\/)/i.test(p.img||"")?`<img class="ph" src="${esc(p.img)}" alt="${esc(p.name)}" loading="lazy" referrerpolicy="no-referrer" onerror="this.remove()">`:"";
// ====== VISUAL BAJU (ilustrasi SVG; foto asli menimpa ilustrasi) ======
const INK="#3B2A4A", PATN=["knit","plaid","argyle","stripes","floral","dots","denim","berry"];
const hex=v=>/^#[0-9a-f]{6}$/i.test(v||"")?v:"#FFB3D1";
function shade(h,p){const n=parseInt(h.slice(1),16),f=x=>Math.max(0,Math.min(255,Math.round(p<0?x*(1+p):x+(255-x)*p)));return "#"+[n>>16,n>>8&255,n&255].map(x=>f(x).toString(16).padStart(2,"0")).join("");}
function garment(p){
  const c=hex(p.color),a=hex(p.accent),d=shade(c,-.2),l=shade(c,.4),pat=PATN.includes(p.pat)?p.pat:"";
  const S=`stroke="${INK}" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"`;
  const ST=`fill="none" stroke="#fff" stroke-opacity=".8" stroke-width="1.6" stroke-dasharray="3 3"`;
  const ov=D=>(pat?`<path d="${D}" fill="url(#p-${pat})"/>`:"")+`<path d="${D}" fill="url(#gloss)"/>`;
  const B=(D,f=c)=>`<path d="${D}" fill="${f}" ${S}/>`+ov(D);
  const btn=(x,y)=>`<circle cx="${x}" cy="${y}" r="3.6" fill="${a}" ${S}/>`;
  let s="";
  switch(p.shape){
  case "cardigan": case "sweater": {
    const cd=p.shape==="cardigan";
    const D=cd?"M62 28 L88 22 L100 44 L112 22 L138 28 L162 52 L178 152 L152 158 L142 92 L142 174 L58 174 L58 92 L48 158 L22 152 L38 52 Z":"M62 28 L86 22 Q100 32 114 22 L138 28 L162 52 L178 152 L152 158 L142 92 L142 174 L58 174 L58 92 L48 158 L22 152 L38 52 Z";
    s=B(D)+`<rect x="58" y="164" width="84" height="11" rx="2" fill="${d}" ${S}/><path d="M24 141 L50 147 L48 158 L22 152Z M176 141 L150 147 L152 158 L178 152Z" fill="${d}" ${S}/>`;
    s+=cd?`<path d="M88 22 L100 44 L112 22" fill="none" stroke="${d}" stroke-width="7" stroke-linejoin="round"/><path d="M100 44 V164" fill="none" ${S}/>`+[64,88,112,136,156].map(y=>btn(93,y)).join(""):`<ellipse cx="100" cy="25" rx="16" ry="8" fill="${d}" ${S}/><ellipse cx="100" cy="26" rx="10" ry="4" fill="${shade(c,-.5)}"/>`;
    s+=`<path d="M62 92 L46 60 M138 92 L154 60" ${ST}/>`; break; }
  case "hoodie": case "bear": {
    const D="M64 44 L84 32 Q100 60 116 32 L136 44 L166 68 L180 162 L154 168 L138 98 L138 176 L62 176 L62 98 L46 168 L20 162 L34 68 Z";
    const H="M74 34 Q100 -2 126 34 Q114 66 100 66 Q86 66 74 34Z";
    const ears=p.shape==="bear"?`<circle cx="80" cy="14" r="13" fill="${c}" ${S}/><circle cx="80" cy="15" r="6.5" fill="${l}"/><circle cx="120" cy="14" r="13" fill="${c}" ${S}/><circle cx="120" cy="15" r="6.5" fill="${l}"/>`:"";
    s=B(D)+`<rect x="62" y="166" width="76" height="10" rx="2" fill="${d}" ${S}/><path d="M22 152 L48 158 L46 168 L20 162Z M178 152 L152 158 L154 168 L180 162Z" fill="${d}" ${S}/><path d="M72 126 H128 L136 166 H64 Z" fill="${shade(c,-.08)}" ${S}/>`+ears+`<path d="${H}" fill="${c}" ${S}/>`+ov(H)+`<path d="M85 34 Q100 8 115 34 Q108 56 100 56 Q92 56 85 34Z" fill="${shade(c,-.45)}" ${S}/><path d="M94 64 V92 M106 64 V92" fill="none" stroke="${INK}" stroke-width="6" stroke-linecap="round"/><path d="M94 64 V92 M106 64 V92" fill="none" stroke="${a}" stroke-width="3" stroke-linecap="round"/>`; break; }
  case "jacket": {
    const sd=shade(a,-.2);
    s=B("M68 24 L36 46 L20 150 L46 158 L68 92 Z",a)+B("M132 24 L164 46 L180 150 L154 158 L132 92 Z",a)+B("M68 24 L90 18 Q100 30 110 18 L132 24 L132 174 L68 174 Z")
     +`<path d="M22 140 L48 148 L46 158 L20 150Z M178 140 L152 148 L154 158 L180 150Z" fill="${sd}" ${S}/><rect x="68" y="164" width="64" height="10" fill="${shade(c,-.18)}" ${S}/><path d="M88 20 Q100 34 112 20 L112 11 Q100 25 88 11Z" fill="${sd}" ${S}/><path d="M100 30 V164" fill="none" stroke="${INK}" stroke-width="2" stroke-dasharray="2 3"/><circle cx="84" cy="66" r="11" fill="${a}" ${S}/><text x="84" y="71" text-anchor="middle" font-family="Fredoka,sans-serif" font-weight="700" font-size="14" fill="${INK}">${esc((p.from||"A")[0])}</text>`; break; }
  case "coat": {
    s=B("M62 22 L88 16 L100 40 L112 16 L138 22 L166 46 L180 158 L154 164 L144 92 L152 186 L48 186 L56 92 L46 164 L20 158 L34 46 Z")
     +`<path d="M100 40 V186" fill="none" ${S}/><path d="M88 16 L100 40 L80 76 L68 44Z M112 16 L100 40 L120 76 L132 44Z" fill="${l}" ${S}/>`
     +[88,106,148,166].map(y=>btn(91,y)+btn(109,y)).join("")
     +`<rect x="53" y="118" width="94" height="12" fill="${d}" ${S}/><rect x="93" y="116" width="14" height="16" rx="2" fill="${a}" ${S}/><path d="M56 92 L38 50 M144 92 L162 50 M52 180 H148" ${ST}/>`; break; }
  case "shirt": {
    s=B("M62 28 L88 22 L100 34 L112 22 L138 28 L166 52 L182 160 L156 166 L142 98 L142 180 L58 180 L58 98 L44 166 L18 160 L34 52 Z")
     +`<path d="M100 52 V180" fill="none" ${S}/><path d="M88 22 L100 34 L100 52 L76 40Z M112 22 L100 34 L100 52 L124 40Z" fill="${l}" ${S}/>`
     +[68,92,116,140,162].map(y=>btn(100,y).replace('r="3.6"','r="3"')).join("")
     +`<rect x="64" y="84" width="24" height="24" rx="3" fill="none" ${S}/><rect x="112" y="84" width="24" height="24" rx="3" fill="none" ${S}/><path d="M22 148 L48 154 M178 148 L152 154" ${ST}/>`; break; }
  case "dress": {
    s=B("M76 18 L86 18 L90 54 Q100 62 110 54 L114 18 L124 18 L130 64 L118 92 L174 176 Q100 192 26 176 L82 92 L70 64 Z")
     +`<path d="M100 104 V184 M90 104 L72 182 M110 104 L128 182" fill="none" stroke="${INK}" stroke-opacity=".15" stroke-width="2"/><path d="M82 92 L118 92 L121 102 L79 102Z" fill="${a}" ${S}/><path d="M100 97 L84 88 L84 108Z M100 97 L116 88 L116 108Z" fill="${a}" ${S}/><circle cx="100" cy="97" r="5" fill="${shade(a,-.15)}" ${S}/><path d="M34 172 Q100 188 166 172" ${ST}/>`; break; }
  case "skirt": {
    s=B("M60 44 H140 L170 168 Q100 184 30 168 Z")
     +`<path d="M80 46 L64 174 M100 46 V181 M120 46 L136 174" fill="none" stroke="${INK}" stroke-opacity=".18" stroke-width="2"/><rect x="60" y="30" width="80" height="16" rx="3" fill="${d}" ${S}/><path d="M36 164 Q100 180 164 164" ${ST}/><path d="M100 38 L74 24 L74 52Z M100 38 L126 24 L126 52Z" fill="${a}" ${S}/><circle cx="100" cy="38" r="6" fill="${shade(a,-.15)}" ${S}/>`; break; }
  case "jeans": {
    s=B("M62 22 H138 L156 186 H104 L100 88 L96 186 H44 Z")
     +`<rect x="62" y="22" width="76" height="16" fill="${d}" ${S}/><path d="M100 38 V88" fill="none" ${S}/><path d="M68 42 Q72 64 92 64 M132 42 Q128 64 108 64 M48 176 H98 M102 176 H152" ${ST}/><rect x="72" y="19" width="6" height="14" rx="1" fill="${d}" ${S}/><rect x="122" y="19" width="6" height="14" rx="1" fill="${d}" ${S}/><circle cx="100" cy="30" r="4" fill="${a}" ${S}/>`; break; }
  case "scarf": {
    const T="M118 60 L158 60 L164 172 L112 172 Z";
    s=B(T)+`<path d="M114 138 H162 M114 152 H162" fill="none" stroke="${a}" stroke-width="6"/><path d="${T}" fill="none" ${S}/>`+[116,124,132,140,148,156,162].map(x=>`<path d="M${x} 172 v12" fill="none" stroke="${INK}" stroke-width="2.4" stroke-linecap="round"/>`).join("")
     +B("M30 46 Q100 14 170 46 Q182 58 170 72 Q100 44 30 78 Q16 62 30 46 Z"); break; }
  case "hat": {
    s=B("M18 108 A82 24 0 1 0 182 108 A82 24 0 1 0 18 108Z",d)+B("M58 100 Q54 44 100 44 Q146 44 142 100 Z")
     +`<path d="M57 90 Q100 104 143 90 L142 102 Q100 116 58 102Z" fill="${a}" ${S}/><path d="M66 64 Q100 50 134 64" ${ST}/><ellipse cx="100" cy="108" rx="70" ry="19" ${ST}/>`; break; }
  default: {
    s=B("M60 30 L86 24 Q100 40 114 24 L140 30 L172 62 L152 84 L138 70 L138 172 L62 172 L62 70 L48 84 L28 62 Z")
     +`<path d="M86 24 Q100 40 114 24" fill="none" stroke="${d}" stroke-width="7" stroke-linecap="round"/><polygon points="100,78 106,94 124,94 110,104 115,122 100,111 85,122 90,104 76,94 94,94" fill="${a}" ${S}/><path d="M62 166 H138 M48 84 L62 72 M152 84 L138 72" ${ST}/>`; }
  }
  return `<svg class="g" viewBox="0 0 200 200" role="img" aria-label="Ilustrasi ${esc(p.name)}"><ellipse cx="100" cy="192" rx="64" ry="5" fill="rgba(59,42,74,.16)"/>${s}</svg>`;
}
const visual=p=>(p.shape?garment(p):`<span class="emo">${esc(p.emoji||"🧺")}</span>`)+imgTag(p);


// ====== STATE ======
let SETTINGS={...DEFAULT_SETTINGS,...load("tt_settings",{})};
let PRODUCTS=[];
let sales=load("tt_sales",{});
let cart=load("tt_cart",[]).map(x=>typeof x==="number"?{id:x,q:1}:x);
let user=load("tt_session",null);
let filter="Semua",query="",sort="new";
const norm=p=>{const d=DEFAULTS.find(x=>x.id===p.id)||{};const m={stock:1,sold:0,orig:0,flash:false,desc:"",...d,...p};
  m.price=+m.price||0;m.orig=+m.orig||0;m.stock=Math.max(0,+m.stock||0);m.sold=Math.max(0,+m.sold||0);return m;};
const P=id=>PRODUCTS.find(p=>p.id===id);
const left=p=>Math.max(0,p.stock-(sales[p.id]||0));
const soldN=p=>p.sold+(sales[p.id]||0);
const disc=p=>p.orig>p.price&&p.price>0?Math.round((1-p.price/p.orig)*100):0;

// ====== TOAST & MODAL ======
let tt;
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");clearTimeout(tt);tt=setTimeout(()=>t.classList.remove("show"),2200);}
function openEl(el){$("#overlay").hidden=false;el.hidden=false;}
function closeAll(){document.querySelectorAll(".modal,.drawer,.overlay").forEach(e=>e.hidden=true);}
document.addEventListener("click",e=>{if(e.target.closest("[data-close]")||e.target.id==="overlay")closeAll();});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeAll();});

// ====== TAMPILAN TOKO ======
function applySettings(){
  const r=document.documentElement.style;
  r.setProperty("--brand",hex(SETTINGS.brand||"#0B8A6B"));r.setProperty("--flash",hex(SETTINGS.flash||"#E63946"));
  document.title=`${SETTINGS.name} – Thrift Import Terpercaya`;
  $("#brand").textContent=SETTINGS.name;$("#fName").textContent=SETTINGS.name;$("#fIg").textContent=SETTINGS.instagram||"";
  $("#bTitle").textContent=SETTINGS.bannerTitle;$("#bSub").textContent=SETTINGS.bannerSub;
  $("#uTxt").textContent=+SETTINGS.freeShip>0?`Gratis ongkir reguler untuk belanja minimal ${rp(SETTINGS.freeShip)}`:"Thrift import pilihan, kondisi dicek satu per satu";
}
function renderNav(){
  const list=["Semua",...new Set(PRODUCTS.map(p=>p.from))];
  $("#catNav").innerHTML=list.map(c=>`<button class="cat ${c===filter?"on":""}" data-f="${esc(c)}">${c==="Semua"?"Semua produk":flagOf(c)+" "+esc(c)}</button>`).join("")+`<a class="cat flashl" href="#flash">Flash Sale</a>`;
}
function card(p,fl){
  const lf=left(p),d=disc(p),sd=soldN(p),tot=(sd+lf)||1,pct=Math.min(100,Math.round(sd/tot*100));
  return `<article class="card" data-open="${p.id}" tabindex="0">
    <div class="ph-box">${visual(p)}${d?`<span class="dtag">-${d}%</span>`:""}${lf?"":`<span class="soldout">Habis</span>`}</div>
    <div class="c-body"><h3>${esc(p.name)}</h3>
      <div class="pr"><b>${rp(p.price)}</b>${p.orig>p.price?`<s>${rp(p.orig)}</s>`:""}</div>
      ${fl?`<div class="bar"><i style="width:${pct}%"></i><span>${lf&&lf<=2?"Tersisa "+lf:"Terjual "+sd}</span></div>`
          :`<div class="meta">${flagOf(p.from)} ${esc(p.from)} · ${esc(p.size)} · ${esc(p.cond)}</div><div class="sold">Terjual ${sd}${lf&&lf<=2?` · Tersisa ${lf}`:""}</div>`}
      <button class="addb" data-a="${p.id}" ${lf?"":"disabled"}>${lf?"+ Keranjang":"Habis"}</button>
    </div></article>`;
}
function renderShop(){
  let a=PRODUCTS.filter(p=>(filter==="Semua"||p.from===filter)&&(p.name+" "+p.from+" "+p.size).toLowerCase().includes(query));
  a.sort({new:(x,y)=>y.id-x.id,best:(x,y)=>soldN(y)-soldN(x),low:(x,y)=>x.price-y.price,high:(x,y)=>y.price-x.price}[sort]);
  const fl=PRODUCTS.filter(p=>p.flash&&left(p)>0), show=fl.length>0&&filter==="Semua"&&!query;
  $("#flash").hidden=!show; if(show)$("#flashRow").innerHTML=fl.map(p=>card(p,true)).join("");
  $("#grid").innerHTML=a.map(p=>card(p,false)).join("");
  $("#empty").hidden=a.length>0; $("#count").textContent=`(${a.length})`;
  document.querySelectorAll("#sorts button").forEach(b=>b.classList.toggle("on",b.dataset.sort===sort));
}
$("#catNav").addEventListener("click",e=>{const b=e.target.closest("[data-f]");if(!b)return;filter=b.dataset.f;renderNav();renderShop();});
$("#sorts").addEventListener("click",e=>{const b=e.target.closest("[data-sort]");if(!b)return;sort=b.dataset.sort;renderShop();});
$("#search").addEventListener("input",e=>{query=e.target.value.trim().toLowerCase();renderShop();});
$("#searchForm").addEventListener("submit",e=>{e.preventDefault();$("#semua").scrollIntoView();});
function cardClick(e){
  const a=e.target.closest("[data-a]");if(a){e.stopPropagation();addCart(+a.dataset.a);return;}
  const c=e.target.closest("[data-open]");if(c)openDetail(+c.dataset.open);
}
["#grid","#flashRow"].forEach(s=>{$(s).addEventListener("click",cardClick);$(s).addEventListener("keydown",e=>{if(e.key==="Enter"&&e.target.matches("[data-open]"))openDetail(+e.target.dataset.open);});});

// ====== COUNTDOWN FLASH SALE ======
function flashEnd(){const d=SETTINGS.flashEnd?new Date(SETTINGS.flashEnd):null,n=new Date();if(d&&d>n)return d;const m=new Date(n);m.setHours(24,0,0,0);return m;}
function tick(){const s=Math.max(0,Math.floor((flashEnd()-new Date())/1000)),t=[Math.floor(s/3600),Math.floor(s%3600/60),s%60].map(x=>String(x).padStart(2,"0"));$("#cdH").textContent=t[0];$("#cdM").textContent=t[1];$("#cdS").textContent=t[2];}
setInterval(tick,1000);

// ====== DETAIL PRODUK ======
let dp=null,dq=1;
function openDetail(id){dp=P(id);if(!dp)return;dq=1;drawDetail();closeAll();openEl($("#detail"));}
function drawDetail(){
  const p=dp,lf=left(p),d=disc(p);
  $("#detailBody").innerHTML=`<div class="d-grid"><div class="d-pic">${visual(p)}</div><div class="d-info">
    <h2>${esc(p.name)}</h2><div class="d-meta">Terjual ${soldN(p)} · Stok ${lf}</div>
    <div class="d-price"><b>${rp(p.price)}</b>${p.orig>p.price?`<s>${rp(p.orig)}</s><span class="dtag">-${d}%</span>`:""}</div>
    <dl class="spec"><dt>Asal</dt><dd>${flagOf(p.from)} ${esc(p.from)}</dd><dt>Ukuran</dt><dd>${esc(p.size)}</dd><dt>Kondisi</dt><dd>${esc(p.cond)}</dd></dl>
    <p class="desc">${esc(p.desc||"Belum ada deskripsi.")}</p>
    ${lf?`<div>Jumlah</div><div class="qty"><button data-dq="-1" aria-label="Kurangi">−</button><span>${dq}</span><button data-dq="1" aria-label="Tambah">+</button></div>
    <div class="d-actions"><button class="btn line" data-dadd>Tambah ke keranjang</button><button class="btn" data-dbuy>Beli sekarang</button></div>`
      :`<button class="btn full" disabled>Stok habis</button>`}
  </div></div>`;
}
$("#detail").addEventListener("click",e=>{
  if(!dp)return;const q=e.target.closest("[data-dq]");
  if(q){dq=Math.max(1,Math.min(left(dp),dq+ +q.dataset.dq));drawDetail();return;}
  if(e.target.closest("[data-dadd]")){addCart(dp.id,dq);closeAll();}
  if(e.target.closest("[data-dbuy]")){addCart(dp.id,dq);openCheckout();}
});

// ====== KERANJANG ======
const lines=()=>cart.map(c=>({p:P(c.id),q:c.q})).filter(x=>x.p);
const subtotal=()=>lines().reduce((s,x)=>s+x.p.price*x.q,0);
function addCart(id,q=1){
  const p=P(id);if(!p||!left(p))return toast("Stok habis");
  const c=cart.find(x=>x.id===id),cur=c?c.q:0,nq=Math.min(left(p),cur+q);
  if(nq===cur)return toast(`Stok tinggal ${left(p)}`);
  if(c)c.q=nq;else cart.push({id,q:nq});
  updateCart();toast("Ditambahkan ke keranjang");
}
function updateCart(){
  cart=cart.filter(c=>P(c.id)&&left(P(c.id))>0).map(c=>({id:c.id,q:Math.min(c.q,left(P(c.id)))}));
  save("tt_cart",cart);$("#cartCount").textContent=cart.reduce((s,c)=>s+c.q,0);renderCart();renderShop();
}
function renderCart(){
  $("#cartItems").innerHTML=lines().length?lines().map(({p,q})=>`<div class="item"><div class="im">${visual(p)}</div>
    <div class="t">${esc(p.name)}<small>${esc(p.size)} · ${esc(p.cond)}</small><span class="pp">${rp(p.price)}</span>
      <div class="qty"><button data-cq="${p.id}:-1" aria-label="Kurangi">−</button><span>${q}</span><button data-cq="${p.id}:1" aria-label="Tambah">+</button></div></div>
    <button class="rm" data-r="${p.id}">Hapus</button></div>`).join("")
    :`<p class="empty">Keranjang masih kosong. Pilih produk dulu.</p>`;
  $("#subtotal").textContent=rp(subtotal());
}
$("#cartItems").addEventListener("click",e=>{
  const r=e.target.closest("[data-r]");if(r){cart=cart.filter(x=>x.id!==+r.dataset.r);updateCart();return;}
  const q=e.target.closest("[data-cq]");if(!q)return;const[id,dl]=q.dataset.cq.split(":").map(Number),c=cart.find(x=>x.id===id);
  if(!c)return;const nq=c.q+dl;if(nq<1)cart=cart.filter(x=>x.id!==id);else c.q=Math.min(nq,left(P(id)));updateCart();
});
$("#btnCart").onclick=()=>{renderCart();closeAll();openEl($("#drawer"));};

// ====== LOGIN / DAFTAR (demo: data tersimpan di browser) ======
let mode="login";
async function hash(s){const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(s));return[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("");}
function setMode(m){mode=m;$("#nameWrap").hidden=m==="login";
  document.querySelectorAll(".tabs[class='tabs'] button[data-tab]").forEach(b=>b.classList.toggle("on",b.dataset.tab===m));
  $("#authTitle").textContent=m==="login"?"Masuk ke akun":"Buat akun baru";$("#authSubmit").textContent=m==="login"?"Masuk":"Daftar sekarang";$("#authErr").textContent="";}
$("#authModal .tabs").addEventListener("click",e=>{const b=e.target.closest("[data-tab]");if(b)setMode(b.dataset.tab);});
function renderAuth(){$("#btnAuth").textContent=user?`Hai, ${user.name.split(" ")[0]}`:"Masuk";}
$("#btnAuth").onclick=()=>{
  if(user){if(confirm("Keluar dari akun?")){user=null;localStorage.removeItem("tt_session");renderAuth();toast("Anda sudah keluar");}return;}
  setMode("login");closeAll();openEl($("#authModal"));
};
$("#authForm").addEventListener("submit",async e=>{
  e.preventDefault();const f=new FormData(e.target),email=f.get("email").trim().toLowerCase(),pw=await hash(f.get("password"));
  const users=load("tt_users",[]),found=users.find(u=>u.email===email);
  if(mode==="register"){
    if(found)return $("#authErr").textContent="Email ini sudah terdaftar. Silakan masuk.";
    const u={name:(f.get("name")||"Pelanggan").trim(),email,pw};users.push(u);save("tt_users",users);user={name:u.name,email};
  }else{
    if(!found||found.pw!==pw)return $("#authErr").textContent="Email atau kata sandi belum cocok. Coba lagi.";
    user={name:found.name,email};
  }
  save("tt_session",user);renderAuth();closeAll();e.target.reset();toast(`Selamat datang, ${user.name}`);
});

// ====== CHECKOUT ======
const shipCost=(v,sub)=>v==="kilat"?30000:(+SETTINGS.freeShip>0&&sub>=+SETTINGS.freeShip?0:15000);
function openCheckout(){
  if(!lines().length)return toast("Keranjang masih kosong");
  closeAll();const E=$("#coForm").elements;if(user){E.name.value=user.name;E.email.value=user.email;}
  calc();openEl($("#checkoutModal"));
}
$("#btnCheckout").onclick=openCheckout;
function calc(){
  const sub=subtotal(),ship=shipCost($("#coForm").elements.ship.value,sub);
  $("#coSum").innerHTML=lines().map(({p,q})=>`<div class="row"><span>${esc(p.name)} × ${q}</span><span>${rp(p.price*q)}</span></div>`).join("")
   +`<div class="row"><span>Subtotal</span><span>${rp(sub)}</span></div><div class="row"><span>Ongkir</span><span>${ship?rp(ship):"Gratis"}</span></div>
    <div class="row total"><span>Total bayar</span><b>${rp(sub+ship)}</b></div>`;
}
$("#coForm").elements.ship.addEventListener("change",calc);
function waLink(o){
  let n=String(SETTINGS.wa||"").replace(/\D/g,"");if(!n)return"";if(n.startsWith("0"))n="62"+n.slice(1);
  const t=`Halo, saya mau konfirmasi pesanan ${o.id}\n`+o.items.map(i=>`- ${i.name} x${i.q} = ${rp(i.price*i.q)}`).join("\n")+`\nTotal: ${rp(o.total)} (${o.pay})\nNama: ${o.name}\nAlamat: ${o.address}, ${o.city} ${o.zip}`;
  return `https://wa.me/${n}?text=${encodeURIComponent(t)}`;
}
$("#coForm").addEventListener("submit",e=>{
  e.preventDefault();const f=e.target,E=f.elements,ls=lines();if(!ls.length)return;
  const sub=subtotal(),ship=shipCost(E.ship.value,sub);
  const o={id:"TT-"+Date.now().toString(36).toUpperCase(),items:ls.map(x=>({id:x.p.id,name:x.p.name,price:x.p.price,q:x.q})),sub,ship,total:sub+ship,
    name:E.name.value,phone:E.phone.value,email:E.email.value,address:E.address.value,city:E.city.value,zip:E.zip.value,pay:E.pay.value,date:new Date().toISOString()};
  save("tt_orders",[...load("tt_orders",[]),o]);
  ls.forEach(x=>sales[x.p.id]=(sales[x.p.id]||0)+x.q);save("tt_sales",sales);
  cart=[];updateCart();closeAll();f.reset();
  $("#doneMsg").innerHTML=`Nomor pesanan <b>${o.id}</b><br>Total ${rp(o.total)} via ${esc(o.pay)}.<br>Detail dikirim ke ${esc(o.email)}.`;
  const w=waLink(o),a=$("#doneWa");a.hidden=!w;if(w)a.href=w;openEl($("#doneModal"));
});

// ====== PANEL ADMIN ======
const ADMIN_PIN="1234"; // GANTI PIN INI sebelum dipakai
let draft=[],sdraft={},atab="products";
const SHAPES=[["tee","Kaos"],["cardigan","Cardigan"],["sweater","Sweater rajut"],["hoodie","Hoodie"],["bear","Hoodie beruang"],["jacket","Jaket varsity"],["coat","Trench coat"],["shirt","Kemeja"],["dress","Dress"],["skirt","Rok"],["jeans","Celana jeans"],["scarf","Scarf"],["hat","Topi bucket"]];
const PATS=[["","Polos"],["knit","Rajut"],["plaid","Kotak-kotak"],["argyle","Argyle"],["stripes","Garis"],["floral","Bunga"],["dots","Polkadot"],["denim","Denim"],["berry","Stroberi"]];
$("#btnAdmin").onclick=()=>{
  if(sessionStorage.getItem("tt_admin")!=="1"){
    const pin=prompt("Masukkan PIN admin:");if(pin===null)return;
    if(pin!==ADMIN_PIN)return toast("PIN salah, coba lagi");
    sessionStorage.setItem("tt_admin","1");
  }
  draft=JSON.parse(JSON.stringify(PRODUCTS));sdraft={...SETTINGS};atab="products";renderAdmin();closeAll();openEl($("#adminModal"));
};
function renderAdmin(){
  document.querySelectorAll("#atabs button").forEach(b=>b.classList.toggle("on",b.dataset.at===atab));
  ["#aAdd","#aExport","#aReset"].forEach(s=>$(s).hidden=(atab==="settings"&&s==="#aAdd"));
  if(atab==="settings"){
    const s=sdraft;
    $("#adminList").innerHTML=`<div class="sform">
      <label>Nama toko<input data-s="name" value="${esc(s.name)}"></label>
      <label>Instagram<input data-s="instagram" value="${esc(s.instagram)}"></label>
      <label>Nomor WhatsApp penjual (contoh 6281234567890)<input data-s="wa" inputmode="tel" value="${esc(s.wa)}"></label>
      <label>Gratis ongkir reguler mulai belanja (Rp, 0 = nonaktif)<input data-s="freeShip" type="number" min="0" step="1000" value="${+s.freeShip||0}"></label>
      <label>Warna utama toko<input type="color" data-s="brand" value="${hex(s.brand)}"></label>
      <label>Warna Flash Sale dan harga<input type="color" data-s="flash" value="${hex(s.flash)}"></label>
      <label class="w2">Flash Sale berakhir (kosongkan agar reset otomatis tiap tengah malam)<input type="datetime-local" data-s="flashEnd" value="${esc(s.flashEnd||"")}"></label>
      <label class="w2">Judul banner<input data-s="bannerTitle" value="${esc(s.bannerTitle)}"></label>
      <label class="w2">Teks banner<textarea data-s="bannerSub" rows="2">${esc(s.bannerSub)}</textarea></label></div>`;
    return;
  }
  $("#adminList").innerHTML=`<datalist id="cl">${Object.keys(FLAGS).map(c=>`<option value="${c}">`).join("")}</datalist>`+draft.map((p,i)=>`
  <div class="arow" data-i="${i}">
    <div class="apv">${visual(p)}</div>
    <div class="afields">
      <label class="w2">Nama produk<input data-k="name" value="${esc(p.name)}"></label>
      <label>Harga jual (Rp)<input data-k="price" type="number" min="0" step="500" inputmode="numeric" value="${p.price}"></label>
      <label>Harga coret (Rp, 0 = tanpa diskon)<input data-k="orig" type="number" min="0" step="500" inputmode="numeric" value="${p.orig||0}"></label>
      <label>Stok<input data-k="stock" type="number" min="0" value="${p.stock}"></label>
      <label>Terjual<input data-k="sold" type="number" min="0" value="${p.sold}"></label>
      <label>Negara asal<input data-k="from" list="cl" value="${esc(p.from)}"></label>
      <label>Ukuran<input data-k="size" value="${esc(p.size)}"></label>
      <label>Kondisi<input data-k="cond" value="${esc(p.cond)}" placeholder="9/10"></label>
      <label class="chk"><input type="checkbox" data-k="flash" ${p.flash?"checked":""}>Tampil di Flash Sale</label>
      <label class="w4">Deskripsi<textarea data-k="desc" rows="2">${esc(p.desc)}</textarea></label>
      <label>Bentuk ilustrasi<select data-k="shape">${SHAPES.map(([v,t])=>`<option value="${v}" ${p.shape===v?"selected":""}>${t}</option>`).join("")}</select></label>
      <label>Pola kain<select data-k="pat">${PATS.map(([v,t])=>`<option value="${v}" ${(p.pat||"")===v?"selected":""}>${t}</option>`).join("")}</select></label>
      <label>Warna utama<input type="color" data-k="color" value="${hex(p.color)}"></label>
      <label>Warna aksen<input type="color" data-k="accent" value="${hex(p.accent||"#FFFFFF")}"></label>
      <label class="w2">Link foto asli (https://...)<input data-k="img" type="url" value="${p.img&&!p.img.startsWith("data:")?esc(p.img):""}" placeholder="https://contoh.com/foto.jpg"></label>
      <label class="w2">Atau upload foto${p.img&&p.img.startsWith("data:")?" (foto upload aktif)":""}<input type="file" accept="image/*" data-up></label>
    </div>
    <button class="rm" type="button" data-del>Hapus</button>
  </div>`).join("");
}
$("#atabs").addEventListener("click",e=>{const b=e.target.closest("[data-at]");if(b){atab=b.dataset.at;renderAdmin();}});
$("#adminList").addEventListener("input",e=>{
  const t=e.target;
  if(t.dataset.s){sdraft[t.dataset.s]=t.type==="number"?Math.max(0,parseInt(t.value,10)||0):t.value;return;}
  const row=t.closest(".arow"),k=t.dataset.k;if(!row||!k)return;
  const p=draft[+row.dataset.i];
  p[k]=t.type==="checkbox"?t.checked:["price","orig","stock","sold"].includes(k)?Math.max(0,parseInt(t.value,10)||0):t.value;
  if(["img","shape","pat","color","accent"].includes(k))row.querySelector(".apv").innerHTML=visual(p);
});
$("#adminList").addEventListener("change",async e=>{
  if(!e.target.matches("[data-up]")||!e.target.files[0])return;
  draft[+e.target.closest(".arow").dataset.i].img=await shrink(e.target.files[0]);renderAdmin();
});
$("#adminList").addEventListener("click",e=>{
  const d=e.target.closest("[data-del]");if(!d)return;const i=+d.closest(".arow").dataset.i;
  if(confirm(`Hapus "${draft[i].name}" dari toko?`)){draft.splice(i,1);renderAdmin();}
});
function shrink(file){return new Promise(res=>{const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{
  const s=Math.min(1,800/Math.max(im.width,im.height)),c=document.createElement("canvas");c.width=im.width*s;c.height=im.height*s;
  c.getContext("2d").drawImage(im,0,0,c.width,c.height);res(c.toDataURL("image/jpeg",.8));};im.src=r.result;};r.readAsDataURL(file);});}
$("#aAdd").onclick=()=>{draft.unshift(norm({id:Date.now(),name:"Produk baru",from:"Jepang",size:"M",cond:"9/10",price:50000,orig:0,stock:1,sold:0,flash:false,desc:"",shape:"tee",color:"#FFB3D1",accent:"#FFFFFF",pat:"",img:""}));renderAdmin();};
$("#aSave").onclick=()=>{
  if(draft.some(p=>!String(p.name).trim()||!(p.price>0)))return toast("Nama dan harga jual wajib diisi");
  PRODUCTS=draft.map(p=>norm({...p,name:String(p.name).trim()}));SETTINGS={...DEFAULT_SETTINGS,...sdraft};
  save("tt_products",PRODUCTS);save("tt_settings",SETTINGS);
  filter="Semua";applySettings();renderNav();updateCart();tick();closeAll();toast("Perubahan tersimpan");
};
$("#aExport").onclick=()=>{const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify({settings:sdraft,products:draft},null,2)],{type:"application/json"}));a.download="products.json";a.click();};
$("#aReset").onclick=()=>{if(confirm("Kembalikan ke produk dan pengaturan bawaan? Perubahanmu akan hilang.")){
  localStorage.removeItem("tt_products");localStorage.removeItem("tt_settings");localStorage.removeItem("tt_sales");
  sales={};SETTINGS={...DEFAULT_SETTINGS};PRODUCTS=DEFAULTS.map(norm);filter="Semua";applySettings();renderNav();updateCart();closeAll();}};

// ====== MULAI ======
(async()=>{
  const mine=load("tt_products",null);let data=null;
  if(mine)data=mine;
  else{try{const r=await fetch("products.json",{cache:"no-store"});if(r.ok){const d=await r.json();
    if(Array.isArray(d)&&d.length)data=d;else if(d&&Array.isArray(d.products)&&d.products.length){data=d.products;if(d.settings&&!localStorage.getItem("tt_settings"))SETTINGS={...DEFAULT_SETTINGS,...d.settings};}}}catch{}}
  PRODUCTS=(data||DEFAULTS).map(norm);
  applySettings();renderNav();renderAuth();updateCart();tick();
})();
